/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo_patolli;

import javax.swing.JFrame;

/**
 *
 * @author david
 */
public class Ventana extends JFrame{
    public Ventana(){
        this.setTitle("Ejemlo");
        this.setSize(950, 950);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Lienzo l = new Lienzo();
        this.add(l);
        
        
    }
}
