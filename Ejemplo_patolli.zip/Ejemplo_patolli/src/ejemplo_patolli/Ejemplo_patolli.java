
package ejemplo_patolli;

/**
 *
 * @author david
 */
public class Ejemplo_patolli {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ventana x = new Ventana();
        x.setVisible(true);
    }
    
}
