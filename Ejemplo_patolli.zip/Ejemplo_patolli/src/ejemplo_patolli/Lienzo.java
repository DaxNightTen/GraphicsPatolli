/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo_patolli;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;

/**
 *
 * @author david
 */
public class Lienzo extends JPanel{
    public Lienzo(){
 
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        
        g.setColor(Color.ORANGE);
        Graphics2D g2d = (Graphics2D)g;
        Graphics2D g2d1 = (Graphics2D)g;
        Graphics2D g2circle = (Graphics2D)g;
        
    int c = 100;
        
        
        
        for (int i = 0; i < 12; i++) {
            g2d.fillRect(c, 400, 50, 50);
            c = c + 50 + 10;
        }
        int c1 = 100;
        for (int i = 0; i < 12; i++) {
            g2d.fillRect(c1, 460, 50, 50);
            c1 = c1 + 50 + 10;
        }
        
        
    
        
        int c2 = 100;
        
        for (int i = 0; i < 12; i++) {
            g2d.fillRect(400, c2, 50, 50);
            c2 = c2 + 50 + 10;
        }
        int c3 = 100;
        for (int i = 0; i < 12; i++) {
            g2d.fillRect(460, c3, 50, 50);
            c3 = c3 + 50 + 10;
        }
      ///////////////////////////////////
        int [] x1 = {130, 180, 155};
        int [] y1 = {400, 400, 455};
        g2d1.setColor(Color.red);
        g2d1.fillPolygon(x1, y1, 3);
        
        int [] x2 = {155, 130, 180};
        int [] y2 = {455, 510, 510};
        g2d1.fillPolygon(x2, y2, 3);
        
        
        
       ///////////////////////////////////
        int [] x3 = {455, 400, 400};
        int [] y3 = {155, 180, 130};
        g2d1.fillPolygon(x3, y3, 3);
        
        int [] x4 = {455, 510, 510};
        int [] y4 = {155, 130, 185};
        g2d1.fillPolygon(x4, y4, 3);
        
        ////////////////////////////////
        int [] x5 = {730, 780, 755};
        int [] y5 = {400, 400, 455};
        g2d1.fillPolygon(x5, y5, 3);
        
        int [] x6 = {755, 730, 780};
        int [] y6 = {455, 510, 510};
        g2d1.fillPolygon(x6, y6, 3);
        //////////////////////////////////
        
        int [] x7 = {455, 400, 400};
        int [] y7 = {755, 780, 730};
        g2d1.fillPolygon(x7, y7, 3);
        
        int [] x8 = {455, 510, 510};
        int [] y8 = {755, 730, 785};
        g2d1.fillPolygon(x8, y8, 3);
        //-------------------------------------
         g2d1.setColor(Color.ORANGE);
        int [] xx = {95,55,45,95};
        int [] yy = {400,410,450,450};     
        g2d1.fillPolygon(xx, yy, 4);
        
        int [] xx1 = {95,45,55,95};
        int [] yy1 = {460,460,500,510};     
        g2d1.fillPolygon(xx1, yy1, 4);
        //---------------------------------
        int [] xx2 = {815,855,865,815}; //+720+800+815+720
        int [] yy2 = {400,410,450,450};   
        g2d1.fillPolygon(xx2, yy2, 4);
        
        int [] xx3 = {815,865,855,815};
        int [] yy3 = {460,460,500,510};     
        g2d1.fillPolygon(xx3, yy3, 4);
        //------------------------------------
        int [] xx4 = {400,450,450,410}; 
        int [] yy4 = {95, 95,45, 55};   
        g2d1.fillPolygon(xx4, yy4, 4);
        
        int [] xx5 = {460,510,500,460}; 
        int [] yy5 = {95, 95, 55, 45};   
        g2d1.fillPolygon(xx5, yy5, 4);
        
        //------------------------------------ 
        int [] xx6 = {400,450,450,410}; 
        int [] yy6 = {815, 815,870, 855};   
        g2d1.fillPolygon(xx6, yy6, 4);
        
        int [] xx7 = {460,510,500,460}; 
        int [] yy7 = {815, 815,855, 870};   
        g2d1.fillPolygon(xx7, yy7, 4);
        
        //-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-//-/
        g2d1.setColor(Color.BLUE);
        g2circle.fillOval(460, 100, 50, 50);
        g2d1.setColor(Color.GREEN);
        g2circle.fillOval(100, 400, 50, 50);
        g2d1.setColor(Color.CYAN);
        g2circle.fillOval(400, 760, 50, 50);
        g2d1.setColor(Color.MAGENTA);
        g2circle.fillOval(760, 460, 50, 50);
        
        g.setColor(Color.BLUE);
        g.drawString ("Jugador 1", 520, 50);
        g.drawString ("Dinero: 5000", 520, 65);
        g.drawString ("N°fichas: 6", 520, 80);
        g.drawString ("En turno", 520, 95);
        
        g.setColor(Color.MAGENTA);
        g.drawString ("Jugador 2", 800, 550);
        g.drawString ("Dinero: 5000", 800, 565);
        g.drawString ("N°fichas: 6", 800, 580);
       
        
        
        
        g.setColor(Color.CYAN);
        g.drawString ("Jugador 3", 520, 750);
        g.drawString ("Dinero: 5000", 520, 765);
        g.drawString ("N°fichas: 6", 520, 780);
        
        g.setColor(Color.GREEN);
        g.drawString ("Jugador 4", 100, 550);
        g.drawString ("Dinero: 5000", 100, 565);
        g.drawString ("N°fichas: 6", 100, 580);
        
        ///////-----------//////////////-----------///////
        g.setColor(Color.DARK_GRAY);
        g.fillRect(550, 250, 50, 100);
        g.setColor(Color.WHITE);
        g.fillOval(570, 290, 10, 10);
        g.setColor(Color.DARK_GRAY);
        g.fillRect(650, 250, 50, 100);
    }
    
    
}
